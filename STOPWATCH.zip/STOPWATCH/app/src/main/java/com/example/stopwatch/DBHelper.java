package com.example.stopwatch;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {
    public DBHelper(Context context) {
        super(context, "StopWatch.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table prev(tm Text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists prev");
    }
    public Cursor getData() {
        SQLiteDatabase DB = this.getReadableDatabase();
        String query = "select * from prev";
        Cursor cursor = DB.rawQuery(query, null);
        return cursor;
    }

    public Boolean addData(String tm) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("tm", tm);
        long result = db.insert("prev", null, contentValues);
        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }
}
